

function [resultados]=Estatisticas(dir_dados)

%%DESCRICAO: O presente codigo tem como objetivo calcular as seguintes
%            estatisticas: 
%
%               - Media
%               - Desvio Padrao
%               - Coeficiente de Variacao
%
%    Como parametros de entrada devera-se fornecer o diretorio que contem
%    os totais anuais a serem processados, estes podem ser totais anuais
%    por ano civil ou por ano hidrologico. 
%
%    Os dados a serem processados deverão estar organizado da seguinte
%    forma: 
%
%                            | Ano |P_Total |
%
%   os dados a serem processados são totais anuais por ano hidrológico (1)
%   ou totais anuais por ano civil (2), as quais são nomeadas da seguiente 
%   forma pelo programa PDPANA: 
%
%           (1): Tot_ah_0'Codigo_Estacao'.csv
%           (2): Tot_ac_0'Codigo_Estacao'.csv
%   
%   É importante ressaltar que a seguinte funcao tem por objetivo estimar
%   as estatisticas para as series geradas pelo programa PDPANA.
%
%   Como resultados será gerada a seguinte tabela:
%
%                     | Codigo | media | dp | cv |
%
%   OBSERVACAO: Os arquivos do diretorio de dados (dir_dados) deverão estar
%   em formato csv. 
%
%
%% IDENTIFICANDO OS ARQUIVOS A SEREM PROCESSADOS 

    cd(dir_dados);        %localizando o diretorio dos dados
    addpath(dir_dados);   %fixa o Diretorio dos dados
    nomes_arq= extrair_nomes(dir_dados);
    
%% ESTIMANDO A QUANTIDADE DE DADOS

    n=size(nomes_arq,1);


%% ESTIMANDO AS ESTATISTICAS DA SERIE
%  
% O presente programa leva em consideração unicamente os dados com
% registros, não leva em consideração o dados ausentes;

    for i=1:n
    arquivo=nomes_arq(i);
    dados=table2array(readtable(arquivo));          %Lendo o arquivo de entrada
    media(i,1)=mean(dados(:,2),'omitnan');          %Estimando a media
    dp(i,1)= std(dados(:,2),'omitnan');             %Estimando o desvio padrao
    cv(i,1)= dp(i)/media(i) ;                       %Estimando o CV
    Cod_est(i,1)=extractBefore(extractAfter(extractAfter(nomes_arq(i),'_'),'_'),'.');  %extraindo o Codigo
    end
    
    Cod_est=str2double(Cod_est);
    
    resultados=table(Cod_est,media,dp,cv);
    resultados=table2array(resultados);
    
end
