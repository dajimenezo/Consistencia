%%                  EXECUÇÃO DO ETAPA DE CONSISTENCIA
%
% A seguir, sera verificada a consistencia dos dados a serem empregados no
% presente estudo, para o qual seram executadas as seguintes funções:
%
%                       * Cercania;
%                       * Correlação;
%                       * Estatisticas;
%                       * Dupla_massa.

%% INSERINDO OS PARAMETROS DAS FUNCOES:
%

  DIR_BASE= 'E:\1.3 ACADEMIA_\3.15 DISSERTACAO\2_ETAPA_1_CONSISTENCIA\1_PROGRAMA';  %DIRETORIO BASE
  RESULTADOS= 'E:\1.3 ACADEMIA_\3.15 DISSERTACAO\2_ETAPA_1_CONSISTENCIA\3_RESULTADOS';     %DIRETORIO PARA ARMAZENAR RESULTADOS;
  
% FUNCAO CONSISTENCIA

INF_BASE='E:\1.3 ACADEMIA_\3.15 DISSERTACAO\2_ETAPA_1_CONSISTENCIA\2_DADOS_A_PROCESSAR'; %DIRETORIO DADOS A PROCESSAR;
NOM_ARQ= 'COORDENADAS.csv';     %NOME DO ARQUIVO DE COORDENADAS

% FUNCAO CORRELACAO

DADOS_FC='E:\1.3 ACADEMIA_\3.15 DISSERTACAO\2_ETAPA_1_CONSISTENCIA\2_DADOS_A_PROCESSAR\1_TOT_A_AH'; %DADOS A SER PROCESSADOS;
ARQUIVO= 'Proximidade.csv';


% FUNCAO CURVA DE DUPLA MASSA

Nome_dados= 'Tot_ah_0';    %Nome dos arquivos;
RE_DM='E:\1.3 ACADEMIA_\3.15 DISSERTACAO\2_ETAPA_1_CONSISTENCIA\3_RESULTADOS\DUPLA_MASSA';


% ADICIONANDO OS DIRETORIOS

addpath(INF_BASE);
addpath(RESULTADOS);
addpath(DIR_BASE);
addpath(DADOS_FC);
addpath(RE_DM);

%% EXECUTANDO A FUNCAO CERCANIA
                 
cercania(NOM_ARQ,INF_BASE, RESULTADOS); % Execucao da funcao cercania;
cd(DIR_BASE);    %retornando para o diretorio Base

%% EXECUTANDO A FUNÇÃO CORRELACAO

correlacao(DADOS_FC,ARQUIVO,RESULTADOS,1); %1 indica que os dados a serem processados sao os totais anuais por ano hidrologico.
cd(DIR_BASE);

%% EXECUTANDO A FUNCAO ESTATISTICAS
%
%
% Estimando as estatisticas das series completas: 
%
[resultados]=Estatisticas(DADOS_FC);    % estatisticas dos dados a serem processados; 
cd(INF_BASE);                           %Diretorio dos arquivo base;
Coor= readtable(NOM_ARQ);               %Lendo o arquivo das coordenadas
Codigos=table2array(Coor(:,1));         %Gerando o vetor codigos
Latitud=table2array(Coor(:,3));         %Gerando o vetor latitude
longitud=table2array(Coor(:,4));        %Gerando o vetor longitude
nomes=table2cell(Coor(:,2));                        %Gerando o vetor nomes

clear Coor;

for i=1: size(resultados,1)
    
    a=find(resultados(i,1)==Codigos);   %posição da estacao no arquivo coordenadas
    Codigo(i,1)=Codigos(a);
    Nome(i,1)=nomes(a);
    Latitude(i,1)=Latitud(a);
    Longitude(i,1)=longitud(a);
    
end

    media=resultados(:,2);
    dp=resultados(:,3);
    cv=resultados(:,4);
    
    Estatisticas=table(Codigo,Nome,Latitude,Longitude,media,dp,cv);
    cd(RESULTADOS);
    writetable(Estatisticas,'Estatisticas.csv','Delimiter',';');
    cd(DIR_BASE)
    
    clear a Codigo Codigos i Latitud Latitude Longitude longitud Nome nomes ...
          resultados cv dp media Estatisticas
      
%% EXECUTANDO A FUNCAO DUPLA MASSA

cd(RESULTADOS);
Corre= table2array(readtable('CORRELACAO.csv'));

%Gerando os nomes dos arquivos;



   con=strcat(Nome_dados,num2str(Corre(:,1)),'.csv');  %Estação a consistir
   b1=strcat(Nome_dados,num2str(Corre(:,2)),'.csv');   %Estacao base 1
   b2=strcat(Nome_dados,num2str(Corre(:,3)),'.csv');
   b3=strcat(Nome_dados,num2str(Corre(:,4)),'.csv');
   b4=strcat(Nome_dados,num2str(Corre(:,5)),'.csv');
   

   
 for i=1:size(con,1)
    cd(DIR_BASE);
 
 
     [Acum]=Dupla_massa(con(i,:),b1(i,:),b2(i,:),b3(i,:),b4(i,:),INF_BASE,RE_DM)
      
     ano=Acum(:,1);
     A_posto=Acum(:,2);
     A_medio=Acum(:,3);
     
     resul=table(ano, A_posto, A_medio);
     writetable(resul, con(i,:) ,'Delimiter',';');
     close;
 end  

 
 clear i