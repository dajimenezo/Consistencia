function [Nome_arquivos] = extrair_nomes(diretorio)

%EXEMPLO DE DIRETORIO DE ARQUIVOS CSV: 'E:\1.3 ACADEMIA_\3.7 PROGRAMAS MATLAB\2.EXTRAER_DADOS ANA\PROGRAMA FINAL\DADOS_BRUTOS\'

s1='\*.csv';
ruta= strcat(diretorio,s1);
folder = dir(ruta);

%PEGAR OS NOMES

Nome_arquivos=[];
Nome_arquivos=string(Nome_arquivos);
for i=1:size(folder,1);
    Nome_arquivos(i,1)= string(folder(i).name);
end 
   
clear folder i

end