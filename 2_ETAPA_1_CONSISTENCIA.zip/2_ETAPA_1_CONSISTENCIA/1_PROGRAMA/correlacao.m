

function []=correlacao(dir_dados,arquivo,resultados_dir,totais)


%%                              DESCRICAO
% A presente funcao tem como objetivo estimar o coeficiente de correlacao
% entre as estacoes mais proximas identificadas mediante a funcao
% cercania. 
%
% Como parametros de entrada a funcao emprega os seguinetes parametros: 
%      
%    -dir_dados: diretorio dos dados a serem analisados;
%    -arquivo: Nome arquivo gerado com a funcao cercania;
%    -resultados: diretorio dos resultados; 
%
% A função correlação gera um arquivo que é armazenado no diretorio de
% resultados, o qual possui a seguinte estrutura: 
%
%  |Est. Analisada | Est. proxima 1 ... 4|Ano Ini|Ano Fin|Corr 1 ... 4 |
%
%
% Se os totais a serem processados forem os totais anuais por ano
% hidrologico devera se establecer 1, se forem os totais por ano civil
% devera se marcar 2.
%

%% DEFININDO OS DIRETORIOS 
proximidade=arquivo;         %Nome do arquivo gerado com a funcao cercania
resultados =resultados_dir   %diretorio com o arquivo de proximidade
addpath(resultados);         %Adiciona o diretorio resultados
addpath(dir_dados);          %Adiciona diretorio com os dados

%% LEITURA DOS DADOS

dados=table2cell(readtable(proximidade));    %Leitura do arquivo. 
dados2=dados;
cd(dir_dados);                               %fixando o diretorio dos dados
dados=string(dados);


%% Gerando o arquivo com o nome dos dados

if totais==1
    nom='Tot_ah_0';
end

if totais==2
    nom='Tot_ac_0';
end

nomes2=strcat(nom, dados(:,:),'.csv');   %gerando os nomes dos arquivos do diretorio de totais anuais por ano Hidrologico



%% ESTIMANDO OS COEFICIENTES DE CORRELACAO DE PEARSON

for i=1:size(dados,1)

Esta_ana= table2array(readtable(nomes2(i,1)));  %Esta. Analise
Esta_prox_1= table2array(readtable(nomes2(i,2)));  %Esta. proxima 1
Esta_prox_2= table2array(readtable(nomes2(i,3)));  %Esta. proxima 2
Esta_prox_3= table2array(readtable(nomes2(i,4)));  %Esta. proxima 3
Esta_prox_4= table2array(readtable(nomes2(i,5)));  %Esta. proxima 4

%definindo ano inicial e final

AI=max([Esta_ana(1,1),Esta_prox_1(1,1),Esta_prox_2(1,1),Esta_prox_3(1,1),Esta_prox_4(1,1)]);
AF=min([Esta_ana(size(Esta_ana,1),1),Esta_prox_1(size(Esta_prox_1,1),1),Esta_prox_2(size(Esta_prox_2,1),1)...
    Esta_prox_3(size(Esta_prox_3,1),1),Esta_prox_4(size(Esta_prox_4,1),1)]);

Esta_ana=Esta_ana(find(Esta_ana(:,1)==AI):find(Esta_ana(:,1)==AF),:);
Esta_prox_1=Esta_prox_1(find(Esta_prox_1(:,1)==AI):find(Esta_prox_1(:,1)==AF),:);
Esta_prox_2= Esta_prox_2(find(Esta_prox_2(:,1)==AI):find(Esta_prox_2(:,1)==AF),:);
Esta_prox_3= Esta_prox_3(find(Esta_prox_3(:,1)==AI):find(Esta_prox_3(:,1)==AF),:);
Esta_prox_4=Esta_prox_4(find(Esta_prox_4(:,1)==AI):find(Esta_prox_4(:,1)==AF),:);

A=[Esta_ana(:,2),Esta_prox_1(:,2),Esta_prox_2(:,2),Esta_prox_3(:,2),Esta_prox_4(:,2)];

resultados=corrcoef(A,'Rows','pairwise');
correla(i,1:2)=[AI,AF];
correla(i,3:7)=resultados(1,:);

end

%% Gerando a tabela de resultados

Esta_Analise= dados2(:,1);
Esta_Prox_1_= dados2(:,2);
Esta_Prox_2_= dados2(:,3);
Esta_Prox_3_= dados2(:,4);
Esta_Prox_4_= dados2(:,5);
Ano_Ini=correla(:,1);
Ano_Fin=correla(:,2);
Corr_0=correla(:,3);
Corr_1=correla(:,4);
Corr_2=correla(:,5);
Corr_3=correla(:,6);
Corr_4=correla(:,7);

corre = table(Esta_Analise, Esta_Prox_1_, Esta_Prox_2_,Esta_Prox_3_, Esta_Prox_4_,...
          Ano_Ini, Ano_Fin, Corr_0,Corr_1,Corr_2,Corr_3,Corr_4);

cd(resultados_dir);
writetable(corre, 'CORRELACAO.csv','Delimiter',';');
      

end

