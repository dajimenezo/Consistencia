
function []=cercania(arquivo,diretorio, dir_saida)

% A funcao cercania estima quais sao as 4 estacoes pluviometricas mais
% proximas a estacao em analise. 
%
% A proximidade e estimada a partir da distancia euclidiana. Como saida a
% funcao gera uma matriz de 4 colunas com as seguintes carateristicas: 
%
%           |ESTA_INTERES|ESTA_PROX_1|...|ESTA_PROX_4|
%
%
% A funcao emprega os seguintes parametros de entrada: 
%
%   *Arquivo: Nome do documento em formato csv com as informações das 
%             estacoes a serem consistidas: 
%
%           | CODIGO DA ESTACAO | NOME | LONGITUDE | LATITUDE |
%
%    *Diretorio: Diretorio onde esta armazenado o arquivo.
%    *dir_saida: Diretorio de saida, onde serao armazenados os resultados
%
%--------------------------------------------------------------------------

%%1 LENDO OS DADOS 
%diretorio='E:\1.3 ACADEMIA_\3.15 DISSERTACAO\2_ETAPA_1_CONSISTENCIA\ESTA_COSISTENCIA.csv';
%arquivo='ESTA_COSISTENCIA.csv';

cd(diretorio);
dados=readtable(arquivo);                             %Abre arquivo com coordenadas

%%2 ARRUMANDO OS DADOS PROCESSADOS EM 1

coordenadas(:,1)= table2array(dados(:,1));            %vetor |codigo|longitude|latitude
coordenadas(:,2)= table2array(dados(:,3));            %vetor |codigo|longitude|latitude
coordenadas(:,3)= table2array(dados(:,4));            %vetor |codigo|longitude|latitude

%%3 ESTABELECENDO AS DISTANCIAS EUCLIDIANAS ENTRE ESTACOES

for i=1:size(coordenadas,1);

    x1=coordenadas(i,2);
    y1=coordenadas(i,3);
    
    for j=1:size(coordenadas,1)
        x2=coordenadas(j,2);
        y2=coordenadas(j,3);
        d(j,1)= sqrt((x1-x2)^2 + (y1-y2)^2);
    end
    
    coordenadas(:,4)= d ;          %Adiciona coluna da distancia
    coordenadas(:,5)= 1:size(coordenadas,1);
    A= sortrows(coordenadas,4);    %ordena vetor coordenadas a partir da distancia
    
    %Vetor com codigos das estacoes proximas
    
    Estacoes_prox(i,1)= coordenadas(i,1);             %Estacao de interes
    Estacoes_prox(i,2)= A(2,1);                       %Estacao mais proxima 1
    Estacoes_prox(i,3)= A(3,1);                      %Estacao mais proxima 2
    Estacoes_prox(i,4)= A(4,1);                       %Estacao mais proxima 3
    Estacoes_prox(i,5)= A(5,1);                       %Estacao mais proxima 4
  
end

    %%GERANDO A TABELA DE RESULTADOS
    
    ESTACAO_ANALISE=Estacoes_prox(:,1);
    ESTACAO_PROX_1=Estacoes_prox(:,2);
    ESTACAO_PROX_2=Estacoes_prox(:,3);
    ESTACAO_PROX_3=Estacoes_prox(:,4);
    ESTACAO_PROX_4=Estacoes_prox(:,5);
    PROXIMIDADE=table(ESTACAO_ANALISE,ESTACAO_PROX_1,ESTACAO_PROX_2,ESTACAO_PROX_3,ESTACAO_PROX_4);
    cd(dir_saida);
    writetable(PROXIMIDADE, 'Proximidade.csv','Delimiter',';');
end