 
%O presente codigo tem por objetivo gerar um arquivo com as medias, os
%desvios padroes e os coeficientes de variacao das estacoes a serem
%empregadas no presente estudo. 
%
% Como resultado será obtido um arquivo com o nome da estação, suas
% coordenadas, e as estatisticas calculadas (Media, dp, CV). 
%
% 

%% Definindo os diretorios e nomes dos arquivos

%Preencher os seguintes dados;
coordenadas='E:\1.3 ACADEMIA_\3.15 DISSERTACAO\2_ETAPA_1_CONSISTENCIA\1_HOMOGENEIDAD\4 DOCUMENTACION\';  %Rota que contem o arquivo coordenadas
n_cor= 'ESTA_ANALISADAS.csv';                                                                            %Nome do arquivo que contem as coordenadas
diretorio='E:\1.3 ACADEMIA_\3.15 DISSERTACAO\2_ETAPA_1_CONSISTENCIA\1_HOMOGENEIDAD\2_TOT_A_AH';          %Rota do arquivo a sere analisado
dir_pro='E:\1.3 ACADEMIA_\3.15 DISSERTACAO\2_ETAPA_1_CONSISTENCIA\1_HOMOGENEIDAD\0_PROGRAMA';            %Rota do Código
resultados ='E:\1.3 ACADEMIA_\3.15 DISSERTACAO\2_ETAPA_1_CONSISTENCIA\1_HOMOGENEIDAD\3_RESULTADOS'       %Rota para salvar os resultados
Nome_resultados='R_Homo_Tot_AH.csv';                                                                     %Nome do arquivo com as estatisticas 
cordenadas_Prox='E:\1.3 ACADEMIA_\3.15 DISSERTACAO\2_ETAPA_1_CONSISTENCIA\1_HOMOGENEIDAD\3_COORDENADAS'; %Rota do arquivo para rodar funcao cercania
Nom_arq_Coor='COORDENADAS.csv';                                                                          %Nome do arquivo com as coordenadas
Nom_arq_prox='Proximidade.csv';                                                                          %Nome do arquivo gerado com a funcao cercania


%--------------------------------------------------------------------------

addpath(coordenadas);
addpath(diretorio);
addpath(dir_pro);

%OBSERVACAO: O arquivo de coordenadas deverá ser um arquivo em formato
%.csv com a seguinte estrutura: 
%
%   | CODIGO | NOME | LONGITUDE | LATITUDE | ANO INICIAL REGISTROS | ANO FINAL REGISTROS |
%
%  Por outro lado, os arquivos a serem analisados deverao cumprir com as
%  carateristicas requeridas para rodar a funcao estatisticas (olhar funcao
%  Estatisticas).
%
% É importante ressaltar que tanto o arquivo de coordenadas, como o
% diretorio das estacoes a serem analisadas deverao relacionar as mesmas
% estacoes pluviometricas.
%
%


%% ABRINDO OS ARQUIVOS
  
  cd(coordenadas);          %Abre o diretorio do arquivo de coordenadas
  coor=readtable(n_cor);    %Lê o arquivo de coordenadas;
  
% gerando um vetor com os nomes dos arquivos do diretorio
%  
   Nomes_arq=extrair_nomes(diretorio);
   
   clear n_cor %elimina a variável n_cor
   
   cd(dir_pro);
   
%% ESTABELECENDO O PERIODO COMUM DOS DADOS

   codigos=table2array(coor(:,1));         %converte a num os codigos
   nomes=table2array(coor(:,2));           %Gera vetor com nomes estacoes
   latitude=table2array(coor(:,3));        %converte a num as latitudes
   longitude=table2array(coor(:,4));       %converte a num as longitudes
   AI=table2array(coor(:,5));              %Converte a num os anos Iniciais
   AF=table2array(coor(:,6));              %Converte a num os anos finais

  clear coor                           %Apaga tabela Coor

  
%Periodo comum 

   ai=max(AI);
   af=min(AF);
   
 % mostrar mensagem de erro se ai>af, e se af é muito velho
 
 if ai>af
 error('Ano Final Maior que Ano Inicial, Favor revisar os dados');
 end 
 
%% CALCULANDO AS ESTATISTICAS DAS SERIES PARA O PERIODO COMUM
%
% O presente fragmento de codigo tem por objetivo estimar a media o desvio
% padrao e o coeficiente de variacao das estacoes analisadas na segunda
% etapa.
 
  for i=1:size(Nomes_arq,1)
 
   [med,dpa,cva]=Estatisticas(Nomes_arq(i));
      
   media(i,1)=med;
   dp(i,1)=dpa;
   cv(i,1)=cva;
   
  end
 
%% Gerando os resultados   
   
   ressultados=table(codigos,nomes,longitude,latitude,media,dp,cv);
   cd(resultados);
   writetable(ressultados, Nome_resultados,'Delimiter',';');
   cd(dir_pro);

%% ESTIMANDO AS ESTACOES PROXIMAS


cercania(Nom_arq_Coor,cordenadas_Prox,resultados);  %Estima as estacoes mais proximas
cd(dir_pro);

[corre]=correlacao(diretorio,Nom_arq_prox,resultados);

cd(dir_pro);



clear af AF ai AI codigos coordenadas cv cva dir_pro diretorio ...
      dp dpa i latitude longitude med media nomes Nomes_arq resultados ...
      Nome_resultados Estacoes_prox cordenadas_Prox Nom_arq_Coor ressultados...
      corre Nom_arq_prox;
  
  
  