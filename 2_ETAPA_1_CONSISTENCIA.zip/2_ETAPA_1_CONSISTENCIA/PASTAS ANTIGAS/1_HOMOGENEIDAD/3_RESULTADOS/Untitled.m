

% A presente funcao tem como objetivo estimar o coeficiente de correlacao
% entre as estacoes mais proximas, identificadas mediante a funcao
% cercania. 
%
% Como parametros de entrada a funcao emprega o arquivo gerado por meio da
% funcao cercania, o qual possui a seguintes carateristicas: 
%
%
%   |Est. Analise|Esta. Prox 1|Esta. Prox 2|Esta. Prox 3|Esta. Prox 4|
%
%


dir_dados='E:\1.3 ACADEMIA_\3.15 DISSERTACAO\2_ETAPA_1_CONSISTENCIA\1_HOMOGENEIDAD\2_TOT_A_AH';
proximidade='Proximidade.csv';               %Nome do arquivo gerado com a funcao cercania
dados=table2cell(readtable(proximidade));    %Leitura do arquivo. 
cd(dir_dados);                               %fixando o diretorio dos dados
dados=string(dados);


%% Gerando o arquivo com o nome dos dados

nomes2=strcat('Tot_ah_0', dados(:,:),'.csv');   %gerando os nomes dos arquivos do diretorio de totais anuais por ano Hidrologico

%% ESTIMANDO OS COEFICIENTES DE CORRELACAO DE PEARSON

Esta_ana= table2array(readtable(nomes2(i,1)));  %Esta. Analise
Esta_prox_1= table2array(readtable(nomes2(i,2)));  %Esta. proxima 1
Esta_prox_2= table2array(readtable(nomes2(i,3)));  %Esta. proxima 2
Esta_prox_3= table2array(readtable(nomes2(i,4)));  %Esta. proxima 3
Esta_prox_4= table2array(readtable(nomes2(i,4)));  %Esta. proxima 4

%definindo ano inicial e final

AI=max([Esta_ana(1,1),Esta_prox_1(1,1),Esta_prox_2(1,1),Esta_prox_3(1,1),Esta_prox_4(1,1)]);
AF=min([Esta_ana(size(Esta_ana,1),1),Esta_prox_1(size(Esta_prox_1,1),1),Esta_prox_2(size(Esta_prox_2,1),1)...
    Esta_prox_3(size(Esta_prox_3,1),1),Esta_prox_4(size(Esta_prox_4,1),1)]);




