

function [media,dp,cv]=Estatisticas(arquivo)

%%DESCRICAO: O presente codigo tem como objetivo calcular as seguintes
%            estatisticas: 
%
%
%               - Media
%               - Desvio Padrao
%               - Coeficiente de Variacao
%
%    Como parametros de entrada devera-se fornecer um arquivo com os totais
%    anuais já seja por ano hidrologico ou por ano civil, o qual devera ter
%    a seguiente estrutura: 
%
%                            | Ano |P_Total |
%
%   OBSERVACAO: O arquivo fornecido devera estar em formato csv. 
%
%% ESTIMANDO AS ESTATISTICAS DA SERIE
%
% O presente programa leva em consideração unicamente os dados com
% registros, não leva em consideração o dados ausentes;
%
    dados=table2array(readtable(arquivo));     %Lendo o arquivo de entrada
    media=mean(dados(:,2),'omitnan');          %Estimando a media
    dp= std(dados(:,2),'omitnan');             %Estimando o desvio padrao
    cv= dp/media                               %Estimando o CV
% 
end
