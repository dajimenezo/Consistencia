function [Acum]=Dupla_massa(consistir, b1,b2,b3,b4)

%A presente funcao grafica as curvas de dupla massa das precipitacoes
%totais anuais. 


%A funcao emprega como parametros de entrada os registros pluviometricos
%das estacoes a serem consistidas, assim como as 4 estacoes bases, a
%informacao deve estar organizada da seguinte forma:
%
%                   |Ano|precipitacao total anual|


%consistir, b1,b2,b3,b4 = nome 


format bank ;

a_consistir=table2array(readtable(consistir));     %posto a consistir
base1 =table2array(readtable(b1));                 %estacao base 1 para a consistencia
base2 =table2array(readtable(b2));                 %estacao base 2 para a consistencia
base3 =table2array(readtable(b3));                 %estacao base 3 para a consistencia%
base4 =table2array(readtable(b4));                 %estacao base 4 para a consistencia


%ARRUMANDO DE MAIOR PARA MENOR

a_consistir=sortrows(a_consistir,1,'descend');
base1=sortrows(base1,1,'descend');
base2=sortrows(base2,1,'descend');
base3=sortrows(base3,1,'descend');
base4=sortrows(base4,1,'descend');

%ANOS INICIAIS E FINAIS DAS SERIES A SEREM CONSISTIDA 

%A consistir

AI_AC= a_consistir(1,1);
AF_AC= a_consistir(size(a_consistir,1),1);

%base 1
AI_B1= base1(1,1);
AF_B1= base1(size(base1,1),1);

%base 2
AI_B2= base2(1,1);
AF_B2= base2(size(base2,1),1);

%base 3
AI_B3= base3(1,1);
AF_B3= base3(size(base3,1),1);

%Base4
AI_B4= base4(1,1);
AF_B4= base4(size(base4,1),1);

%ANOS EM COMUM DAS SÉRIES


AI= max([AI_AC, AI_B1, AI_B2, AI_B3]);%, AI_B4])
AF= min([AF_AC, AF_B1, AF_B2, AF_B3]);%, AF_B4])


%GERANDO A MATRIZ COM OS REGISTROS METEOROLOGICOS

dados=sort([AF:AI],'descend')';    %datas

for i=1:size(dados,1);

dados(i,2) = a_consistir(find(a_consistir==dados(i,1)),2);  %A consistir
dados(i,3) = base1(find(base1==dados(i,1)),2);              %Base 1
dados(i,4) = base2(find(base2==dados(i,1)),2);              %Base 2
dados(i,5) = base3(find(base3==dados(i,1)),2);              %Base 3
dados(i,6) = base4(find(base4==dados(i,1)),2);              %Base 4

if i>1 
    Acum(i,1)=dados(i,1);
    Acum(i,2)=dados(i,2)+Acum(i-1,2);
    Acum(i,3)=mean(dados(i,3:6))+Acum(i-1,3);   % trocar 5 por 6
else
    Acum(i,1)=dados(i,1);
    Acum(i,2)=dados(i,2);
    Acum(i,3)=mean(dados(i,3:6));                % trocar 5 por 6
    
end


end

%Gerando o grafico da dupla massa.

plot((Acum(:,3)/1000),(Acum(:,2)/1000),'-O', 'LineWidth',10);
grid on;
xtickformat('%.1f');
ytickformat('%.1f');
set(gca,'fontsize',20);

yl=strcat('P acumulada x 1000 (mm), Posto :  ',extractBefore(consistir,".csv"));

ylabel( yl,'FontSize',20);
xlabel('P acumulada x 1000 (mm), Posto médio','FontSize',20);

text(((Acum(:,3)/1000)+0.5),((Acum(:,2)/1000)-0.5),string(Acum(:,1)),'FontSize',20);


x0=1;
y0=41;
width=1920;
height=963;
set(gcf,'position',[x0,y0,width,height]);

figura=strcat(extractBefore(consistir,".csv"),'.png');
saveas(gcf,figura);
figura=strcat(extractBefore(consistir,".csv"),'.fig');
savefig(gcf,figura);

end 
